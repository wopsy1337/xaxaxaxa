# Kurulum ve Çalıştırma

## Gereksinimler
- Node.js (v14 veya üzeri)
- npm veya yarn

## Kurulum Adımları

1. **Bağımlılıkları yükleyin:**
```bash
npm install
```

2. **.env dosyasını düzenleyin:**
`.env` dosyasındaki `YourUsername` kısmını kendi Windows kullanıcı adınızla değiştirin.

Örnek:
```
APPDATA=C:\Users\Ahmet\AppData\Roaming
LOCALAPPDATA=C:\Users\Ahmet\AppData\Local
TEMP=C:\Users\Ahmet\AppData\Local\Temp
```

3. **Programı çalıştırın:**
```bash
npm start
```

## Debug Modu

VSCode'da F5 tuşuna basarak debug modunda çalıştırabilirsiniz.

## Notlar

- Windows ortamında çalıştırılmalıdır
- Bazı işlevler yönetici yetkisi gerektirebilir
